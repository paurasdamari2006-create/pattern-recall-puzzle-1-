import React, { useState } from 'react';
import { JAVA_SWING_CODE } from '../data/javaCode';
import { X, Copy, Check, Download, Terminal, Code2, Cpu, ExternalLink } from 'lucide-react';

interface JavaCodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JavaCodeViewerModal: React.FC<JavaCodeViewerModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'instructions' | 'architecture'>('code');

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(JAVA_SWING_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([JAVA_SWING_CODE], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = 'PatternRecallGame.java';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-[#0b1120] border border-slate-800 rounded-2xl w-full max-w-5xl h-[88vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800/80 bg-[#0d1527]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">PatternRecallGame.java</h3>
                <span className="text-[11px] font-mono bg-blue-950/70 border border-blue-800/60 text-blue-300 px-2 py-0.5 rounded">
                  Java Swing Desktop
                </span>
              </div>
              <p className="text-xs text-slate-400">Pure Java Swing desktop GUI matching the 6x6 pattern memory interface</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Source'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm shadow-blue-500/20 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .java</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors ml-2"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-800/80 bg-[#090e1c]">
          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'code'
                ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Complete Java Source</span>
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'instructions'
                ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>How to Compile & Run</span>
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'architecture'
                ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>Swing Architecture Highlights</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-auto bg-[#070b14]">
          {activeTab === 'code' && (
            <div className="p-6">
              <pre className="font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto p-4 rounded-xl bg-[#090f1d] border border-slate-800/80 selection:bg-blue-600">
                <code>{JAVA_SWING_CODE}</code>
              </pre>
            </div>
          )}

          {activeTab === 'instructions' && (
            <div className="p-8 max-w-3xl space-y-6 text-sm text-slate-300">
              <div className="space-y-2">
                <h4 className="text-lg font-bold text-white">How to Run on Any Computer (macOS, Windows, Linux)</h4>
                <p className="text-slate-400">
                  Because this code uses 100% standard Java SE libraries (<code className="text-blue-300">javax.swing</code>, <code className="text-blue-300">java.awt</code>, and <code className="text-blue-300">javax.sound.midi</code>), no external JARs or build tools (like Maven or Gradle) are required. Any JDK (Java 8 or higher, including JDK 11, 17, or 21) works immediately.
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Step 1: Save the File</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-2">
                    Click the <strong>"Download .java"</strong> button above or copy the code into a file named exactly:
                  </p>
                  <div className="bg-[#070b14] p-2.5 rounded font-mono text-xs text-emerald-400 border border-slate-800">
                    PatternRecallGame.java
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Step 2: Compile from Terminal / Command Prompt</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-2">
                    Open your command line in the directory where the file is saved and run:
                  </p>
                  <div className="bg-[#070b14] p-2.5 rounded font-mono text-xs text-yellow-300 border border-slate-800 flex items-center justify-between">
                    <span>javac PatternRecallGame.java</span>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Step 3: Launch the Game</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-2">
                    Run the compiled bytecode using the Java runtime:
                  </p>
                  <div className="bg-[#070b14] p-2.5 rounded font-mono text-xs text-emerald-400 border border-slate-800 flex items-center justify-between">
                    <span>java PatternRecallGame</span>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-blue-950/20 border border-blue-900/40 text-xs text-blue-300/90 leading-relaxed">
                  <strong>Audio Note:</strong> The Java code utilizes Java's built-in <code className="text-white">MidiSystem</code> synthesizer to play synthesized melodic tones for each lit tile, click feedback, and victory fanfares without needing any external audio assets!
                </div>
              </div>
            </div>
          )}

          {activeTab === 'architecture' && (
            <div className="p-8 max-w-3xl space-y-6 text-sm text-slate-300">
              <h4 className="text-lg font-bold text-white">Swing Technical Architecture</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <h5 className="font-semibold text-white text-sm mb-1">Custom Antialiased TileButton</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Inherits from <code className="text-blue-300">JButton</code> and overrides <code className="text-blue-300">paintComponent()</code>. Uses <code className="text-blue-300">RenderingHints.KEY_ANTIALIASING</code>, <code className="text-blue-300">RoundRectangle2D</code>, and a vertical <code className="text-blue-300">GradientPaint</code> to recreate the screenshot's glowing cyan-to-blue active state and white center dot.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <h5 className="font-semibold text-white text-sm mb-1">Non-Blocking javax.swing.Timer</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Uses Swing's built-in single-thread event dispatch timers (<code className="text-blue-300">javax.swing.Timer</code>) instead of dangerous <code className="text-blue-300">Thread.sleep()</code> calls. This ensures the GUI remains responsive, repaint events process cleanly, and animations never freeze.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <h5 className="font-semibold text-white text-sm mb-1">Dual Recall Game Mechanics</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Supports both <strong>Matrix Pattern Recall</strong> (where tiles flash simultaneously for 1.8s) and <strong>Sequential Order Recall</strong> (where tiles flash sequentially like Simon).
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#0d1629] border border-slate-800">
                  <h5 className="font-semibold text-white text-sm mb-1">Built-in MIDI Tone Synthesis</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Generates clean musical notes using the standard Java MIDI subsystem (<code className="text-blue-300">MidiSystem.getSynthesizer()</code>), producing melodic pitch feedback for every tile and error buzzers for mistakes.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800/80 bg-[#0d1527] text-xs text-slate-400">
          <span>Self-contained in <code>PatternRecallGame.java</code> in project root</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
