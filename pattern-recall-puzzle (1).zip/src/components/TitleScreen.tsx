import React, { useState, useEffect } from 'react';
import { Play, Code2, Sparkles, Brain, Volume2, VolumeX, ShieldCheck } from 'lucide-react';

interface TitleScreenProps {
  onStart: () => void;
  gameMode: 'matrix' | 'sequence';
  setGameMode: (mode: 'matrix' | 'sequence') => void;
  gridSize: number;
  setGridSize: (size: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenJavaModal: () => void;
  highScore: number;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  gameMode,
  setGameMode,
  gridSize,
  setGridSize,
  isMuted,
  onToggleMute,
  onOpenJavaModal,
  highScore,
}) => {
  // Animated preview tile indices for the hero lockup
  const [activePreviewTiles, setActivePreviewTiles] = useState<number[]>([1, 5, 10, 19, 20]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Pick 4-5 random tiles to highlight on the 5x5 preview
      const indices: number[] = [];
      while (indices.length < 5) {
        const rand = Math.floor(Math.random() * 25);
        if (!indices.includes(rand)) indices.push(rand);
      }
      setActivePreviewTiles(indices);
    }, 1800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-[90vh] flex flex-col items-center justify-center px-4 py-8 max-w-4xl mx-auto text-center">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Bespoke inline SVG Title Lockup */}
      <div className="relative mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-800/40 text-blue-400 text-xs font-medium mb-3">
          <Brain className="w-3.5 h-3.5 text-blue-400" />
          <span>Visual Cognitive Memory Benchmark</span>
        </div>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-none mb-3">
          PATTERN <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500">RECALL</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-400 max-w-lg mx-auto">
          Test and train your visual working memory on the glowing electric matrix. Memorize active tiles and recall the pattern without errors.
        </p>
      </div>

      {/* Hero Centerpiece: Pulsing Interactive 5x5 Preview Board */}
      <div className="relative my-4 p-3 bg-[#090e1a]/90 border border-[#1b273d] rounded-2xl shadow-[0_0_40px_rgba(37,99,235,0.25)]">
        <div className="grid grid-cols-5 gap-2 w-[200px] h-[200px] sm:w-[230px] sm:h-[230px]">
          {Array.from({ length: 25 }).map((_, i) => {
            const isLit = activePreviewTiles.includes(i);
            return (
              <div
                key={i}
                className={`relative flex items-center justify-center rounded-xl transition-all duration-300 ${
                  isLit
                    ? 'bg-gradient-to-b from-[#60a5fa] via-[#2563eb] to-[#1d4ed8] border border-blue-300/80 shadow-[0_0_15px_rgba(59,130,246,0.8)] scale-105'
                    : 'bg-[#0e1628] border border-[#1a2942]'
                }`}
              >
                {isLit ? (
                  <span className="w-2 h-2 rounded-full bg-white shadow-[0_0_6px_#ffffff]" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#384863]" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Game Mode & Grid Size Configuration */}
      <div className="w-full max-w-md my-4 space-y-3">
        {/* Game Mode Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#0b1222] border border-[#1e2c45] rounded-xl">
          <button
            onClick={() => setGameMode('matrix')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
              gameMode === 'matrix'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Matrix Recall (Simultaneous)
          </button>
          <button
            onClick={() => setGameMode('sequence')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
              gameMode === 'sequence'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sequence Recall (In Order)
          </button>
        </div>

        {/* Grid Size Selector */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#0b1222] border border-[#1e2c45] rounded-xl text-xs">
          <span className="text-slate-400 font-medium">Grid Dimension:</span>
          <div className="flex items-center gap-1.5">
            {[
              { size: 3, label: '3x3' },
              { size: 4, label: '4x4' },
              { size: 5, label: '5x5' },
              { size: 6, label: '6x6 (Master)' },
            ].map((opt) => (
              <button
                key={opt.size}
                onClick={() => setGridSize(opt.size)}
                className={`px-2.5 py-1 rounded-md text-xs font-mono transition-colors ${
                  gridSize === opt.size
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/50 font-bold'
                    : 'text-slate-400 hover:text-white bg-slate-800/40 border border-transparent'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Primary Start CTA Button */}
      <div className="flex flex-col sm:flex-row items-center gap-3 mt-2">
        <button
          onClick={onStart}
          className="flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm sm:text-base rounded-xl shadow-[0_0_30px_rgba(59,130,246,0.4)] transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
        >
          <Play className="w-5 h-5 fill-white" />
          <span>START GAME</span>
        </button>

        <button
          onClick={onOpenJavaModal}
          className="flex items-center justify-center gap-2 px-5 py-3.5 bg-[#0e1628] hover:bg-[#152038] text-slate-300 hover:text-white border border-[#233554] text-xs sm:text-sm font-medium rounded-xl transition-colors cursor-pointer"
        >
          <Code2 className="w-4 h-4 text-blue-400" />
          <span>Java Swing Code (.java)</span>
        </button>
      </div>

      {/* Single Flat Control-Hint Line */}
      <div className="mt-8 text-xs text-slate-400 font-mono tracking-tight flex items-center justify-center gap-2 flex-wrap">
        <span>Click Tiles to Recall</span>
        <span>·</span>
        <span>Space / Enter to Start</span>
        <span>·</span>
        <span>M to Mute</span>
        <span>·</span>
        <span>R to Restart</span>
      </div>

      {/* High Score / Best Banner */}
      {highScore > 0 && (
        <div className="mt-4 text-xs font-mono text-slate-400">
          Personal Best: <span className="text-amber-400 font-bold">{highScore} pts</span>
        </div>
      )}
    </div>
  );
};
