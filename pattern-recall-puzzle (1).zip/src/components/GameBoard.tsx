import React from 'react';

interface GameBoardProps {
  gridSize: number;
  pattern: number[];
  revealedTiles: Set<number>;
  correctlyClicked: Set<number>;
  wrongClicked: number | null;
  isRecallPhase: boolean;
  onTileClick: (index: number) => void;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  gridSize,
  pattern,
  revealedTiles,
  correctlyClicked,
  wrongClicked,
  isRecallPhase,
  onTileClick,
}) => {
  const totalTiles = gridSize * gridSize;

  // Compute CSS grid template
  const gridStyle: React.CSSProperties = {
    gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
  };

  return (
    <div className="relative flex items-center justify-center p-2">
      {/* Outer ambient glow behind matrix */}
      <div className="absolute -inset-4 bg-blue-600/10 rounded-3xl blur-2xl pointer-events-none" />

      {/* Main Grid Wrapper matching image.png */}
      <div 
        className="relative bg-[#090e1a]/95 border border-[#1b273d] p-3.5 sm:p-4 md:p-5 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.8),inset_0_0_30px_rgba(10,18,36,0.6)] backdrop-blur-md transition-all duration-300"
      >
        <div
          className="grid gap-2 sm:gap-2.5 md:gap-3 w-[310px] h-[310px] sm:w-[420px] sm:h-[420px] md:w-[480px] md:h-[480px] lg:w-[510px] lg:h-[510px]"
          style={gridStyle}
        >
          {Array.from({ length: totalTiles }).map((_, index) => {
            const isLitInPreview = revealedTiles.has(index);
            const isCorrectlyFound = correctlyClicked.has(index);
            const isWrong = wrongClicked === index;
            const isActive = isLitInPreview || isCorrectlyFound;

            return (
              <button
                key={index}
                onClick={() => onTileClick(index)}
                disabled={!isRecallPhase || isCorrectlyFound}
                aria-label={`Tile ${index + 1}`}
                className={`relative flex items-center justify-center rounded-xl sm:rounded-2xl transition-all duration-150 select-none outline-none ${
                  isRecallPhase && !isCorrectlyFound
                    ? 'cursor-pointer active:scale-95'
                    : 'cursor-default'
                } ${
                  isActive
                    ? 'bg-gradient-to-b from-[#60a5fa] via-[#2563eb] to-[#1d4ed8] border border-blue-300/80 shadow-[0_0_20px_rgba(59,130,246,0.7),0_0_40px_rgba(37,99,235,0.4),inset_0_0_12px_rgba(191,219,254,0.7)] scale-[1.02]'
                    : isWrong
                    ? 'bg-gradient-to-b from-rose-500 via-red-600 to-rose-700 border border-red-300 shadow-[0_0_24px_rgba(239,68,68,0.8)] animate-shake'
                    : 'bg-[#0e1628] border border-[#1a2942] hover:border-[#2d446b] hover:bg-[#121c33]'
                }`}
              >
                {/* Center dot design identical to reference screenshot */}
                {isActive ? (
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-white/40 blur-xs" />
                    <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 rounded-full bg-white shadow-[0_0_6px_#ffffff,0_0_12px_#93c5fd]" />
                  </div>
                ) : isWrong ? (
                  <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-white shadow-[0_0_8px_#ffffff]" />
                ) : (
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-[#384863] transition-colors group-hover:bg-[#4d6387]" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
