import React from 'react';
import { Heart, Trophy, Zap, Clock } from 'lucide-react';

interface HUDProps {
  score: number;
  level: number;
  highScore: number;
  lives: number;
  maxLives: number;
  streak: number;
  statusText: string;
  statusType: 'info' | 'active' | 'success' | 'danger';
  memorizeProgress: number; // 0 to 1
  isMemorizePhase: boolean;
  gameMode: 'matrix' | 'sequence';
  targetCount: number;
  foundCount: number;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  level,
  highScore,
  lives,
  maxLives,
  streak,
  statusText,
  statusType,
  memorizeProgress,
  isMemorizePhase,
  gameMode,
  targetCount,
  foundCount,
}) => {
  const getBannerColor = () => {
    switch (statusType) {
      case 'active':
        return 'border-blue-500/40 bg-blue-950/30 text-blue-300';
      case 'success':
        return 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300';
      case 'danger':
        return 'border-rose-500/40 bg-rose-950/30 text-rose-300';
      default:
        return 'border-slate-800 bg-[#0d1527] text-slate-300';
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-3">
      {/* Top Stat Bar */}
      <div className="flex items-center justify-between px-5 py-3 rounded-xl bg-[#0b1222] border border-[#1b2842] shadow-sm">
        {/* Level / Round */}
        <div className="flex flex-col">
          <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Round</span>
          <span className="text-xl font-bold text-white font-mono tabular-nums leading-tight">{level}</span>
        </div>

        {/* Score */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Score</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-white font-mono tabular-nums leading-tight">{score}</span>
            {streak > 1 && (
              <span className="text-[11px] font-mono text-amber-400 font-semibold flex items-center">
                <Zap className="w-3 h-3 fill-amber-400 inline" /> {streak}x
              </span>
            )}
          </div>
        </div>

        {/* High Score */}
        <div className="hidden sm:flex flex-col items-center">
          <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider flex items-center gap-1">
            <Trophy className="w-3 h-3 text-amber-400" /> Best
          </span>
          <span className="text-xl font-bold text-slate-300 font-mono tabular-nums leading-tight">{highScore}</span>
        </div>

        {/* Lives */}
        <div className="flex flex-col items-end">
          <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Lives</span>
          <div className="flex items-center gap-1 mt-0.5">
            {Array.from({ length: maxLives }).map((_, i) => (
              <Heart
                key={i}
                className={`w-4 h-4 transition-all duration-200 ${
                  i < lives
                    ? 'text-rose-500 fill-rose-500 scale-100'
                    : 'text-slate-700 fill-slate-800/40 scale-90'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Status Banner */}
      <div className={`relative overflow-hidden px-4 py-2.5 rounded-xl border transition-colors ${getBannerColor()}`}>
        <div className="flex items-center justify-between text-xs sm:text-sm font-medium">
          <div className="flex items-center gap-2">
            {isMemorizePhase && <Clock className="w-4 h-4 animate-spin text-blue-400" />}
            <span>{statusText}</span>
          </div>

          {!isMemorizePhase && targetCount > 0 && (
            <div className="text-xs font-mono tabular-nums text-slate-400">
              <span className="text-blue-400 font-bold">{foundCount}</span> / {targetCount} tiles
            </div>
          )}
        </div>

        {/* Memorize Countdown Bar */}
        {isMemorizePhase && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-950/60 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-75 ease-linear"
              style={{ width: `${Math.max(0, Math.min(100, (1 - memorizeProgress) * 100))}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
