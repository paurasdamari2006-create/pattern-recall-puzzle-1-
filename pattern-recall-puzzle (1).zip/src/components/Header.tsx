import React from 'react';
import { Volume2, VolumeX, Code2, RotateCcw, Home } from 'lucide-react';

interface HeaderProps {
  onGoHome: () => void;
  onRestart: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenJavaModal: () => void;
  gameState: 'TITLE' | 'PLAYING' | 'GAME_OVER';
  gameMode: 'matrix' | 'sequence';
  onSwitchMode: (mode: 'matrix' | 'sequence') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onGoHome,
  onRestart,
  isMuted,
  onToggleMute,
  onOpenJavaModal,
  gameState,
  gameMode,
  onSwitchMode,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-slate-800/80 bg-[#090e1a]/90 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <button
        onClick={onGoHome}
        className="text-lg font-bold tracking-tight text-white hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 text-left cursor-pointer"
      >
        <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-[0_0_8px_#3b82f6]" />
        <span>Pattern Recall</span>
      </button>

      {/* Zone 2: 4 nav links with clean single-line text */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => onSwitchMode('matrix')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            gameMode === 'matrix' ? 'text-blue-400 font-semibold' : ''
          }`}
        >
          Matrix Mode
        </button>
        <button
          onClick={() => onSwitchMode('sequence')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            gameMode === 'sequence' ? 'text-blue-400 font-semibold' : ''
          }`}
        >
          Sequence Mode
        </button>
        <button
          onClick={onToggleMute}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          <span>{isMuted ? 'Muted' : 'Sound On'}</span>
        </button>
        {gameState !== 'TITLE' && (
          <button
            onClick={onRestart}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer text-slate-400 hover:text-amber-300"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        )}
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenJavaModal}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm shadow-blue-500/20 transition-all whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>Java Swing Code</span>
        </button>
      </div>
    </header>
  );
};
