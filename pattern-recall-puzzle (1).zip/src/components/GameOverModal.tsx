import React from 'react';
import { RotateCcw, Trophy, Brain, Sparkles, Code2 } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  level: number;
  highScore: number;
  isNewHigh: boolean;
  onRestart: () => void;
  onOpenJavaModal: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  level,
  highScore,
  isNewHigh,
  onRestart,
  onOpenJavaModal,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0b1120] border border-[#1e2c45] rounded-2xl w-full max-w-md p-6 sm:p-8 text-center shadow-[0_0_60px_rgba(0,0,0,0.9)] relative overflow-hidden">
        {/* Glow ambient */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-24 bg-blue-600/20 rounded-full blur-2xl pointer-events-none" />

        {isNewHigh ? (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 fill-amber-400" />
            <span>NEW HIGH SCORE!</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-medium mb-3">
            <Brain className="w-3.5 h-3.5" />
            <span>SESSION SUMMARY</span>
          </div>
        )}

        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
          Game Over
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mb-6">
          You made your final mistake. Excellent visual pattern recall practice!
        </p>

        {/* Score Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="p-3.5 rounded-xl bg-[#0e1628] border border-[#1b273d]">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block mb-0.5">Final Score</span>
            <span className="text-2xl font-bold font-mono text-white tabular-nums">{score}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#0e1628] border border-[#1b273d]">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block mb-0.5">Round Reached</span>
            <span className="text-2xl font-bold font-mono text-blue-400 tabular-nums">Round {level}</span>
          </div>
        </div>

        <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-[#080d17] border border-[#162238] text-xs font-mono mb-6">
          <span className="text-slate-400 flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" /> All-Time Best
          </span>
          <span className="text-amber-400 font-bold">{highScore} pts</span>
        </div>

        {/* Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={onRestart}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again (Space)</span>
          </button>

          <button
            onClick={onOpenJavaModal}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-[#0e1628] hover:bg-[#142038] text-slate-300 hover:text-white border border-[#233554] text-xs font-medium rounded-xl transition-colors cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5 text-blue-400" />
            <span>View Java Swing Source (.java)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
