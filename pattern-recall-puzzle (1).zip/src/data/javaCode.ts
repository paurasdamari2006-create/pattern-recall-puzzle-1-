export const JAVA_SWING_CODE = `import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.*;
import javax.sound.midi.*;

/**
 * Pattern Recall Puzzle
 * 
 * A sleek, modern desktop visual memory puzzle game built with Java Swing.
 * Features customizable grid dimensions (including the 6x6 layout from the reference image),
 * simultaneous matrix recall & sequence recall modes, custom antialiased glowing tiles,
 * synthesized MIDI audio chimes, level progression, and lives tracking.
 *
 * Compilation & Execution:
 *   javac PatternRecallGame.java
 *   java PatternRecallGame
 */
public class PatternRecallGame extends JFrame {

    // --- Palette Constants Matching Modern Dark Aesthetic ---
    public static final Color COLOR_BG_DARK = new Color(7, 11, 20);
    public static final Color COLOR_PANEL_BG = new Color(11, 17, 32);
    public static final Color COLOR_PANEL_BORDER = new Color(30, 41, 59);
    public static final Color COLOR_TILE_INACTIVE = new Color(15, 23, 42);
    public static final Color COLOR_TILE_BORDER = new Color(30, 48, 77);
    public static final Color COLOR_TILE_DOT = new Color(71, 85, 105);
    
    // Glowing Blue Active State (Reference Image Palette)
    public static final Color COLOR_TILE_ACTIVE_TOP = new Color(96, 165, 250);
    public static final Color COLOR_TILE_ACTIVE_BOTTOM = new Color(37, 99, 235);
    public static final Color COLOR_TILE_ACTIVE_CORE = new Color(191, 219, 254);
    public static final Color COLOR_TILE_GLOW = new Color(59, 130, 246, 140);
    
    // Feedback Colors
    public static final Color COLOR_CORRECT = new Color(34, 197, 94);
    public static final Color COLOR_WRONG = new Color(239, 68, 68);
    public static final Color COLOR_TEXT_MUTED = new Color(148, 163, 184);
    public static final Color COLOR_TEXT_LIGHT = new Color(248, 250, 252);
    public static final Color COLOR_ACCENT = new Color(59, 130, 246);

    // --- Game Modes ---
    public enum GameMode {
        MATRIX_PATTERN("Matrix Recall (Simultaneous)"),
        SEQUENCE_MEMORY("Sequence Recall (In Order)");

        private final String displayName;
        GameMode(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    // --- Game State Variables ---
    private int gridSize = 6;              // Default matching reference photo (6x6)
    private int level = 1;
    private int score = 0;
    private int highScore = 0;
    private int lives = 3;
    private final int MAX_LIVES = 3;
    private GameMode currentMode = GameMode.MATRIX_PATTERN;
    
    // Pattern tracking
    private final java.util.List<Integer> activePattern = new ArrayList<>();
    private final Set<Integer> targetTilesSet = new HashSet<>();
    private final Set<Integer> correctlyGuessedSet = new HashSet<>();
    private int sequenceInputIndex = 0;
    private boolean isAcceptingInput = false;

    // --- UI Components ---
    private JPanel gridPanel;
    private TileButton[] tileButtons;
    private JLabel statusLabel;
    private JLabel scoreLabel;
    private JLabel levelLabel;
    private JLabel livesLabel;
    private JLabel highScoreLabel;
    private JButton startRestartButton;
    private JComboBox<String> modeComboBox;
    private JComboBox<String> sizeComboBox;

    // --- Audio Synthesizer (Standard Java MIDI) ---
    private Synthesizer midiSynth;
    private MidiChannel midiChannel;
    private boolean soundEnabled = true;

    // --- Timers ---
    private javax.swing.Timer flashTimer;
    private javax.swing.Timer sequenceTimer;

    public PatternRecallGame() {
        super("Pattern Recall Puzzle");
        initMidiAudio();
        initUI();
    }

    /**
     * Initializes a lightweight MIDI synth for procedural retro tone feedback.
     */
    private void initMidiAudio() {
        try {
            midiSynth = MidiSystem.getSynthesizer();
            midiSynth.open();
            MidiChannel[] channels = midiSynth.getChannels();
            if (channels != null && channels.length > 0) {
                midiChannel = channels[0];
                // Instrument 80 = Synth Lead
                midiChannel.programChange(80);
            }
        } catch (Exception e) {
            System.out.println("Audio initialization skipped: " + e.getMessage());
            midiChannel = null;
        }
    }

    private void playTone(int note, int velocity, int durationMs) {
        if (!soundEnabled || midiChannel == null) return;
        new Thread(() -> {
            try {
                midiChannel.noteOn(note, velocity);
                Thread.sleep(durationMs);
                midiChannel.noteOff(note);
            } catch (Exception ignored) {}
        }).start();
    }

    /**
     * Constructs the modern dark theme GUI layout.
     */
    private void initUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(780, 860);
        setMinimumSize(new Dimension(650, 750));
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_BG_DARK);
        setLayout(new BorderLayout(0, 0));

        // Top Navigation / Header HUD
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Center Game Arena (Grid Container)
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(COLOR_BG_DARK);
        centerWrapper.setBorder(new EmptyBorder(16, 24, 16, 24));

        gridPanel = new JPanel();
        gridPanel.setBackground(COLOR_PANEL_BG);
        gridPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PANEL_BORDER, 2, true),
            new EmptyBorder(14, 14, 14, 14)
        ));
        
        rebuildGrid(gridSize);
        centerWrapper.add(gridPanel);
        add(centerWrapper, BorderLayout.CENTER);

        // Bottom Controls & Instruction Bar
        JPanel bottomPanel = createBottomPanel();
        add(bottomPanel, BorderLayout.SOUTH);

        // Ready status
        setStatus("Press 'Start Game' to begin", COLOR_TEXT_LIGHT);
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(COLOR_PANEL_BG);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_PANEL_BORDER),
            new EmptyBorder(18, 28, 16, 28)
        ));

        // Top Row: Title & Stats
        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);

        JLabel titleLabel = new JLabel("PATTERN RECALL");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(COLOR_TEXT_LIGHT);
        topRow.add(titleLabel, BorderLayout.WEST);

        // Stats Cluster (Tabular, clean layout)
        JPanel statsCluster = new JPanel(new FlowLayout(FlowLayout.RIGHT, 18, 0));
        statsCluster.setOpaque(false);

        levelLabel = createStatLabel("ROUND", "1");
        scoreLabel = createStatLabel("SCORE", "0");
        highScoreLabel = createStatLabel("BEST", "0");
        livesLabel = createStatLabel("LIVES", "❤❤❤");
        livesLabel.setForeground(new Color(244, 63, 94));

        statsCluster.add(levelLabel);
        statsCluster.add(scoreLabel);
        statsCluster.add(highScoreLabel);
        statsCluster.add(livesLabel);
        topRow.add(statsCluster, BorderLayout.EAST);

        header.add(topRow);
        header.add(Box.createVerticalStrut(12));

        // Bottom Row: Status Message Banner
        JPanel bannerPanel = new JPanel(new BorderLayout());
        bannerPanel.setBackground(COLOR_BG_DARK);
        bannerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PANEL_BORDER, 1, true),
            new EmptyBorder(8, 16, 8, 16)
        ));

        statusLabel = new JLabel("Click 'Start Game' to test your visual memory", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        statusLabel.setForeground(COLOR_ACCENT);
        bannerPanel.add(statusLabel, BorderLayout.CENTER);

        header.add(bannerPanel);
        return header;
    }

    private JLabel createStatLabel(String title, String initialValue) {
        JLabel label = new JLabel(title + ": " + initialValue);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(COLOR_TEXT_LIGHT);
        return label;
    }

    private JPanel createBottomPanel() {
        JPanel bottom = new JPanel(new BorderLayout(16, 0));
        bottom.setBackground(COLOR_PANEL_BG);
        bottom.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, COLOR_PANEL_BORDER),
            new EmptyBorder(14, 28, 16, 28)
        ));

        // Left Options (Mode and Size selector)
        JPanel leftOptions = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftOptions.setOpaque(false);

        JLabel modeLbl = new JLabel("Mode:");
        modeLbl.setForeground(COLOR_TEXT_MUTED);
        modeComboBox = new JComboBox<>(new String[]{"Matrix Recall", "Sequence Recall"});
        modeComboBox.setBackground(COLOR_BG_DARK);
        modeComboBox.setForeground(COLOR_TEXT_LIGHT);
        modeComboBox.setFocusable(false);
        modeComboBox.addActionListener(e -> {
            currentMode = modeComboBox.getSelectedIndex() == 0 
                ? GameMode.MATRIX_PATTERN 
                : GameMode.SEQUENCE_MEMORY;
            resetGame();
        });

        JLabel sizeLbl = new JLabel("Grid:");
        sizeLbl.setForeground(COLOR_TEXT_MUTED);
        sizeComboBox = new JComboBox<>(new String[]{"3 x 3", "4 x 4", "5 x 5", "6 x 6 (Master)"});
        sizeComboBox.setSelectedIndex(3); // Default to 6x6 matching screenshot
        sizeComboBox.setBackground(COLOR_BG_DARK);
        sizeComboBox.setForeground(COLOR_TEXT_LIGHT);
        sizeComboBox.setFocusable(false);
        sizeComboBox.addActionListener(e -> {
            int newSize = sizeComboBox.getSelectedIndex() + 3;
            if (newSize != gridSize) {
                gridSize = newSize;
                rebuildGrid(gridSize);
                resetGame();
            }
        });

        JButton soundBtn = new JButton("Sound: ON");
        soundBtn.setBackground(COLOR_BG_DARK);
        soundBtn.setForeground(COLOR_TEXT_LIGHT);
        soundBtn.setFocusable(false);
        soundBtn.addActionListener(e -> {
            soundEnabled = !soundEnabled;
            soundBtn.setText("Sound: " + (soundEnabled ? "ON" : "OFF"));
        });

        leftOptions.add(modeLbl);
        leftOptions.add(modeComboBox);
        leftOptions.add(sizeLbl);
        leftOptions.add(sizeComboBox);
        leftOptions.add(soundBtn);
        bottom.add(leftOptions, BorderLayout.WEST);

        // Right Actions (Start / Restart)
        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightActions.setOpaque(false);

        startRestartButton = new JButton("Start Game");
        startRestartButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        startRestartButton.setBackground(COLOR_ACCENT);
        startRestartButton.setForeground(Color.WHITE);
        startRestartButton.setFocusPainted(false);
        startRestartButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        startRestartButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        startRestartButton.addActionListener(e -> startRound());

        rightActions.add(startRestartButton);
        bottom.add(rightActions, BorderLayout.EAST);

        return bottom;
    }

    private void rebuildGrid(int size) {
        gridPanel.removeAll();
        gridPanel.setLayout(new GridLayout(size, size, 10, 10));

        int totalTileCount = size * size;
        tileButtons = new TileButton[totalTileCount];

        int preferredSize = 520;
        gridPanel.setPreferredSize(new Dimension(preferredSize, preferredSize));

        for (int i = 0; i < totalTileCount; i++) {
            final int tileIndex = i;
            TileButton btn = new TileButton();
            btn.addActionListener(e -> onTileClicked(tileIndex));
            tileButtons[i] = btn;
            gridPanel.add(btn);
        }

        gridPanel.revalidate();
        gridPanel.repaint();
    }

    private void startRound() {
        startRestartButton.setEnabled(false);
        modeComboBox.setEnabled(false);
        sizeComboBox.setEnabled(false);
        isAcceptingInput = false;

        for (TileButton btn : tileButtons) {
            btn.resetTile();
        }

        correctlyGuessedSet.clear();
        sequenceInputIndex = 0;

        int countToLight = Math.min(3 + (level - 1), (gridSize * gridSize) - 2);
        generateRandomPattern(countToLight);

        if (currentMode == GameMode.MATRIX_PATTERN) {
            runMatrixPhase();
        } else {
            runSequencePhase();
        }
    }

    private void generateRandomPattern(int count) {
        activePattern.clear();
        targetTilesSet.clear();
        int total = gridSize * gridSize;

        java.util.List<Integer> allIndices = new ArrayList<>();
        for (int i = 0; i < total; i++) allIndices.add(i);
        Collections.shuffle(allIndices);

        for (int i = 0; i < count; i++) {
            int idx = allIndices.get(i);
            activePattern.add(idx);
            targetTilesSet.add(idx);
        }
    }

    private void runMatrixPhase() {
        setStatus("Memorize the pattern! (" + targetTilesSet.size() + " tiles)", COLOR_ACCENT);
        playTone(60, 90, 200);

        for (int idx : targetTilesSet) {
            tileButtons[idx].setLit(true);
        }

        int memorizeDuration = Math.max(1200, 2000 - (level * 50));
        flashTimer = new javax.swing.Timer(memorizeDuration, e -> {
            flashTimer.stop();
            for (TileButton btn : tileButtons) {
                btn.setLit(false);
            }
            playTone(67, 80, 150);
            beginRecallPhase();
        });
        flashTimer.setRepeats(false);
        flashTimer.start();
    }

    private void runSequencePhase() {
        setStatus("Watch the sequence carefully...", COLOR_ACCENT);
        final int[] step = {0};

        sequenceTimer = new javax.swing.Timer(550, null);
        sequenceTimer.addActionListener(e -> {
            if (step[0] < activePattern.size()) {
                int tileIdx = activePattern.get(step[0]);
                tileButtons[tileIdx].setLit(true);
                playTone(60 + step[0] * 2, 85, 200);

                javax.swing.Timer offTimer = new javax.swing.Timer(350, offEvt -> {
                    tileButtons[tileIdx].setLit(false);
                });
                offTimer.setRepeats(false);
                offTimer.start();

                step[0]++;
            } else {
                sequenceTimer.stop();
                beginRecallPhase();
            }
        });
        sequenceTimer.setInitialDelay(400);
        sequenceTimer.start();
    }

    private void beginRecallPhase() {
        isAcceptingInput = true;
        if (currentMode == GameMode.MATRIX_PATTERN) {
            setStatus("Your turn! Click all " + targetTilesSet.size() + " tiles.", COLOR_TEXT_LIGHT);
        } else {
            setStatus("Your turn! Repeat the sequence in order.", COLOR_TEXT_LIGHT);
        }
    }

    private void onTileClicked(int index) {
        if (!isAcceptingInput) return;

        TileButton btn = tileButtons[index];

        if (currentMode == GameMode.MATRIX_PATTERN) {
            if (correctlyGuessedSet.contains(index)) return;

            if (targetTilesSet.contains(index)) {
                correctlyGuessedSet.add(index);
                btn.setLit(true);
                playTone(72 + correctlyGuessedSet.size() * 2, 90, 150);

                int remaining = targetTilesSet.size() - correctlyGuessedSet.size();
                if (remaining == 0) {
                    onRoundSuccess();
                } else {
                    setStatus("Correct! " + remaining + " remaining...", COLOR_CORRECT);
                }
            } else {
                btn.flashError();
                playTone(40, 100, 300);
                onMistake();
            }
        } else {
            int expected = activePattern.get(sequenceInputIndex);
            if (index == expected) {
                btn.setLit(true);
                playTone(60 + sequenceInputIndex * 3, 90, 180);
                javax.swing.Timer brief = new javax.swing.Timer(250, ev -> btn.setLit(false));
                brief.setRepeats(false);
                brief.start();

                sequenceInputIndex++;
                if (sequenceInputIndex == activePattern.size()) {
                    onRoundSuccess();
                }
            } else {
                btn.flashError();
                playTone(40, 100, 300);
                onMistake();
            }
        }
    }

    private void onRoundSuccess() {
        isAcceptingInput = false;
        int roundPoints = 100 * level + (currentMode == GameMode.MATRIX_PATTERN ? targetTilesSet.size() * 20 : activePattern.size() * 30);
        score += roundPoints;
        if (score > highScore) highScore = score;

        updateHUD();
        setStatus("Round " + level + " Cleared! +" + roundPoints + " pts", COLOR_CORRECT);

        playTone(72, 90, 200);
        playTone(76, 90, 200);
        playTone(79, 100, 350);

        javax.swing.Timer nextRoundTimer = new javax.swing.Timer(1200, e -> {
            level++;
            updateHUD();
            startRound();
        });
        nextRoundTimer.setRepeats(false);
        nextRoundTimer.start();
    }

    private void onMistake() {
        lives--;
        updateHUD();

        if (lives <= 0) {
            isAcceptingInput = false;
            for (int idx : targetTilesSet) {
                if (!correctlyGuessedSet.contains(idx)) {
                    tileButtons[idx].setLit(true);
                }
            }
            setStatus("Game Over! Final Score: " + score, COLOR_WRONG);
            playTone(36, 110, 600);

            JOptionPane.showMessageDialog(
                this,
                "Game Over!\\n\\nFinal Score: " + score + "\\nRound Reached: " + level + "\\nHigh Score: " + highScore,
                "Game Over",
                JOptionPane.INFORMATION_MESSAGE
            );

            resetGame();
        } else {
            setStatus("Wrong tile! " + lives + " lives remaining. Try again!", COLOR_WRONG);
        }
    }

    private void resetGame() {
        level = 1;
        score = 0;
        lives = MAX_LIVES;
        isAcceptingInput = false;
        updateHUD();

        startRestartButton.setText("Start Game");
        startRestartButton.setEnabled(true);
        modeComboBox.setEnabled(true);
        sizeComboBox.setEnabled(true);

        for (TileButton btn : tileButtons) {
            btn.resetTile();
        }
        setStatus("Game reset. Click 'Start Game' when ready.", COLOR_TEXT_LIGHT);
    }

    private void updateHUD() {
        levelLabel.setText("ROUND: " + level);
        scoreLabel.setText("SCORE: " + score);
        highScoreLabel.setText("BEST: " + highScore);

        StringBuilder sb = new StringBuilder("LIVES: ");
        for (int i = 0; i < lives; i++) sb.append("❤");
        for (int i = lives; i < MAX_LIVES; i++) sb.append("♡");
        livesLabel.setText(sb.toString());
    }

    private void setStatus(String text, Color color) {
        statusLabel.setText(text);
        statusLabel.setForeground(color);
    }

    /**
     * Custom-painted Tile Button replicating the exact visual style in image.png.
     */
    private static class TileButton extends JButton {
        private boolean isLit = false;
        private boolean isError = false;

        public TileButton() {
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        public void setLit(boolean lit) {
            this.isLit = lit;
            this.isError = false;
            repaint();
        }

        public void flashError() {
            this.isError = true;
            this.isLit = false;
            repaint();

            javax.swing.Timer errorReset = new javax.swing.Timer(400, e -> {
                this.isError = false;
                repaint();
            });
            errorReset.setRepeats(false);
            errorReset.start();
        }

        public void resetTile() {
            this.isLit = false;
            this.isError = false;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            int width = getWidth();
            int height = getHeight();
            int arc = Math.min(width, height) / 4;

            int inset = 2;
            int x = inset;
            int y = inset;
            int w = width - (inset * 2);
            int h = height - (inset * 2);

            RoundRectangle2D.Float roundShape = new RoundRectangle2D.Float(x, y, w, h, arc, arc);

            if (isLit) {
                // Active Glowing Blue State
                g2.setColor(COLOR_TILE_GLOW);
                g2.setStroke(new BasicStroke(4f));
                g2.draw(new RoundRectangle2D.Float(x - 1, y - 1, w + 2, h + 2, arc + 2, arc + 2));

                GradientPaint gradient = new GradientPaint(
                    0, y, COLOR_TILE_ACTIVE_TOP,
                    0, y + h, COLOR_TILE_ACTIVE_BOTTOM
                );
                g2.setPaint(gradient);
                g2.fill(roundShape);

                g2.setColor(new Color(255, 255, 255, 60));
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(roundShape);

                int dotSize = Math.max(6, width / 7);
                int dotX = (width - dotSize) / 2;
                int dotY = (height - dotSize) / 2;

                g2.setColor(new Color(255, 255, 255, 120));
                g2.fillOval(dotX - 3, dotY - 3, dotSize + 6, dotSize + 6);

                g2.setColor(Color.WHITE);
                g2.fillOval(dotX, dotY, dotSize, dotSize);

            } else if (isError) {
                g2.setColor(COLOR_WRONG);
                g2.fill(roundShape);
                g2.setColor(Color.WHITE);
                int dotSize = Math.max(6, width / 8);
                g2.fillOval((width - dotSize) / 2, (height - dotSize) / 2, dotSize, dotSize);

            } else {
                g2.setColor(COLOR_TILE_INACTIVE);
                g2.fill(roundShape);

                g2.setColor(COLOR_TILE_BORDER);
                g2.setStroke(new BasicStroke(1.2f));
                g2.draw(roundShape);

                int dotSize = Math.max(4, width / 12);
                int dotX = (width - dotSize) / 2;
                int dotY = (height - dotSize) / 2;
                g2.setColor(COLOR_TILE_DOT);
                g2.fillOval(dotX, dotY, dotSize, dotSize);
            }

            g2.dispose();
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            PatternRecallGame game = new PatternRecallGame();
            game.setVisible(true);
        });
    }
}
`;
