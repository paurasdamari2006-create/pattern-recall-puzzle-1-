import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { TitleScreen } from './components/TitleScreen';
import { GameBoard } from './components/GameBoard';
import { HUD } from './components/HUD';
import { GameOverModal } from './components/GameOverModal';
import { JavaCodeViewerModal } from './components/JavaCodeViewerModal';
import { sound } from './utils/audio';
import { RotateCcw, Volume2, VolumeX, Eye, HelpCircle } from 'lucide-react';

type GameState = 'TITLE' | 'PLAYING' | 'GAME_OVER';
type GameMode = 'matrix' | 'sequence';

export default function App() {
  // Game Configuration & State
  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [gameMode, setGameMode] = useState<GameMode>('matrix');
  const [gridSize, setGridSize] = useState<number>(6); // Default 6x6 matching screenshot
  const [level, setLevel] = useState<number>(1);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('pattern_recall_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });
  const [lives, setLives] = useState<number>(3);
  const [maxLives] = useState<number>(3);
  const [streak, setStreak] = useState<number>(0);

  // Pattern & Interaction State
  const [pattern, setPattern] = useState<number[]>([]);
  const [revealedTiles, setRevealedTiles] = useState<Set<number>>(new Set());
  const [correctlyClicked, setCorrectlyClicked] = useState<Set<number>>(new Set());
  const [wrongClicked, setWrongClicked] = useState<number | null>(null);

  // Status & Timers
  const [statusText, setStatusText] = useState<string>('Get ready...');
  const [statusType, setStatusType] = useState<'info' | 'active' | 'success' | 'danger'>('info');
  const [isMemorizePhase, setIsMemorizePhase] = useState<boolean>(false);
  const [isRecallPhase, setIsRecallPhase] = useState<boolean>(false);
  const [memorizeProgress, setMemorizeProgress] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Modals
  const [isJavaModalOpen, setIsJavaModalOpen] = useState<boolean>(false);
  const [isNewHigh, setIsNewHigh] = useState<boolean>(false);

  // Sequence mode pointer
  const sequenceStepRef = useRef<number>(0);
  const timerRefs = useRef<NodeJS.Timeout[]>([]);
  const animFrameRef = useRef<number | null>(null);

  const clearAllTimers = useCallback(() => {
    timerRefs.current.forEach(t => clearTimeout(t));
    timerRefs.current = [];
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
  }, []);

  // Update High Score if needed
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      setIsNewHigh(true);
      try {
        localStorage.setItem('pattern_recall_highscore', score.toString());
      } catch {}
    }
  }, [score, highScore]);

  // Handle Mute toggle
  const toggleMute = () => {
    const nextMuted = sound.toggleMute();
    setIsMuted(nextMuted);
  };

  /**
   * Start a new round with generated pattern.
   */
  const startRound = useCallback((currentLevel: number, currentGridSize: number, currentMode: GameMode) => {
    clearAllTimers();
    setWrongClicked(null);
    setCorrectlyClicked(new Set());
    setIsRecallPhase(false);
    sequenceStepRef.current = 0;

    // Number of tiles to memorize: scales smoothly with level
    const totalTiles = currentGridSize * currentGridSize;
    // e.g. for 6x6: Level 1 has 4 tiles, Level 2 has 5, Level 3 has 6...
    const count = Math.min(Math.max(3, 3 + (currentLevel - 1)), totalTiles - 4);

    // Pick random unique tiles
    const allIndices = Array.from({ length: totalTiles }, (_, i) => i);
    for (let i = allIndices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allIndices[i], allIndices[j]] = [allIndices[j], allIndices[i]];
    }
    const selectedPattern = allIndices.slice(0, count);
    setPattern(selectedPattern);

    if (currentMode === 'matrix') {
      // --- Matrix Mode: All tiles illuminate simultaneously ---
      setIsMemorizePhase(true);
      setStatusText(`Memorize the pattern! (${count} tiles)`);
      setStatusType('active');

      // Light up all tiles
      setRevealedTiles(new Set(selectedPattern));
      sound.playTile(currentLevel);

      // Duration scales slightly down as level advances (e.g., 2000ms down to 1400ms)
      const duration = Math.max(1400, 2200 - (currentLevel * 60));
      const startTime = Date.now();

      const updateProgress = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(1, elapsed / duration);
        setMemorizeProgress(progress);

        if (progress < 1) {
          animFrameRef.current = requestAnimationFrame(updateProgress);
        } else {
          // Extinguish lights and begin recall
          setRevealedTiles(new Set());
          setIsMemorizePhase(false);
          setIsRecallPhase(true);
          setStatusText(`Your turn! Recall all ${count} tiles.`);
          setStatusType('info');
          sound.playTone(587.33, 0.15, 'sine', 0.12); // turn prompt chime
        }
      };

      animFrameRef.current = requestAnimationFrame(updateProgress);

    } else {
      // --- Sequence Mode: Flash tiles 1 by 1 ---
      setIsMemorizePhase(true);
      setStatusText('Watch the sequence...');
      setStatusType('active');
      setRevealedTiles(new Set());

      selectedPattern.forEach((tileIndex, step) => {
        const t1 = setTimeout(() => {
          setRevealedTiles(new Set([tileIndex]));
          sound.playTile(step, 400);

          const t2 = setTimeout(() => {
            setRevealedTiles(new Set());
          }, 350);
          timerRefs.current.push(t2);

          // Once last tile flashes, start recall
          if (step === selectedPattern.length - 1) {
            const t3 = setTimeout(() => {
              setIsMemorizePhase(false);
              setIsRecallPhase(true);
              setStatusText(`Your turn! Repeat the sequence (${selectedPattern.length} steps).`);
              setStatusType('info');
            }, 500);
            timerRefs.current.push(t3);
          }
        }, 500 + step * 600);

        timerRefs.current.push(t1);
      });
    }
  }, [clearAllTimers]);

  /**
   * Start game from Title Screen.
   */
  const handleStartGame = () => {
    setGameState('PLAYING');
    setLevel(1);
    setScore(0);
    setLives(maxLives);
    setStreak(0);
    setIsNewHigh(false);
    startRound(1, gridSize, gameMode);
  };

  /**
   * Reset game.
   */
  const handleReset = () => {
    clearAllTimers();
    handleStartGame();
  };

  /**
   * Handle Player clicking a tile during recall phase.
   */
  const handleTileClick = (index: number) => {
    if (!isRecallPhase) return;

    if (gameMode === 'matrix') {
      // Matrix recall mode
      if (correctlyClicked.has(index)) return;

      const isTarget = pattern.includes(index);

      if (isTarget) {
        // Correct tile!
        const nextCorrect = new Set(correctlyClicked);
        nextCorrect.add(index);
        setCorrectlyClicked(nextCorrect);
        sound.playCorrect(nextCorrect.size);

        // Small streak and score increment
        setScore(prev => prev + 50 * level);

        const remaining = pattern.length - nextCorrect.size;
        if (remaining === 0) {
          // Round Cleared!
          onRoundSuccess();
        } else {
          setStatusText(`Nice! ${remaining} tile${remaining > 1 ? 's' : ''} left.`);
          setStatusType('success');
        }
      } else {
        // Misclick / Mistake!
        handleMistake(index);
      }
    } else {
      // Sequence recall mode
      const expectedTile = pattern[sequenceStepRef.current];

      if (index === expectedTile) {
        // Correct step in sequence
        sound.playCorrect(sequenceStepRef.current);
        const nextCorrect = new Set(correctlyClicked);
        nextCorrect.add(index);
        setCorrectlyClicked(nextCorrect);

        // Brief lit visual feedback
        setRevealedTiles(new Set([index]));
        setTimeout(() => setRevealedTiles(new Set()), 250);

        sequenceStepRef.current += 1;
        setScore(prev => prev + 40 * level);

        if (sequenceStepRef.current === pattern.length) {
          // Finished full sequence!
          onRoundSuccess();
        } else {
          setStatusText(`Step ${sequenceStepRef.current} / ${pattern.length} correct.`);
          setStatusType('success');
        }
      } else {
        // Incorrect step in sequence!
        handleMistake(index);
      }
    }
  };

  /**
   * Triggered on correct round completion.
   */
  const onRoundSuccess = () => {
    setIsRecallPhase(false);
    clearAllTimers();

    const roundPoints = 150 * level + (streak + 1) * 30;
    setScore(prev => prev + roundPoints);
    setStreak(prev => prev + 1);

    setStatusText(`Round ${level} Complete! +${roundPoints} pts`);
    setStatusType('success');
    sound.playRoundClear();

    // Trigger subtle celebratory confetti
    confetti({
      particleCount: 35,
      spread: 60,
      origin: { y: 0.65 },
      colors: ['#3b82f6', '#60a5fa', '#93c5fd', '#ffffff'],
      disableForReducedMotion: true,
    });

    // Advance to next round after delay
    const t = setTimeout(() => {
      const nextLevel = level + 1;
      setLevel(nextLevel);
      startRound(nextLevel, gridSize, gameMode);
    }, 1200);
    timerRefs.current.push(t);
  };

  /**
   * Triggered on misclick.
   */
  const handleMistake = (misclickedIndex: number) => {
    sound.playMistake();
    setWrongClicked(misclickedIndex);
    setStreak(0);

    const nextLives = lives - 1;
    setLives(nextLives);

    if (nextLives <= 0) {
      // Game Over!
      setIsRecallPhase(false);
      clearAllTimers();
      sound.playGameOver();

      // Show full pattern in error state
      setRevealedTiles(new Set(pattern));
      setStatusText(`Game Over! Final Score: ${score}`);
      setStatusType('danger');

      const t = setTimeout(() => {
        setGameState('GAME_OVER');
      }, 900);
      timerRefs.current.push(t);
    } else {
      setStatusText(`Wrong tile! ${nextLives} ${nextLives === 1 ? 'life' : 'lives'} left.`);
      setStatusType('danger');

      // Clear wrong click highlight after 400ms
      setTimeout(() => {
        setWrongClicked(null);
      }, 400);
    }
  };

  // Keyboard navigation & controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape closes Java code modal
      if (e.key === 'Escape' && isJavaModalOpen) {
        setIsJavaModalOpen(false);
        return;
      }

      // Space or Enter to Start / Restart
      if (e.key === ' ' || e.key === 'Enter') {
        if (gameState === 'TITLE') {
          e.preventDefault();
          handleStartGame();
        } else if (gameState === 'GAME_OVER') {
          e.preventDefault();
          handleReset();
        }
      }

      // M to toggle mute
      if (e.key.toLowerCase() === 'm') {
        toggleMute();
      }

      // R to restart
      if (e.key.toLowerCase() === 'r' && gameState === 'PLAYING') {
        handleReset();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, isJavaModalOpen, gridSize, gameMode]);

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Bar Contract Navigation */}
      <Header
        onGoHome={() => {
          clearAllTimers();
          setGameState('TITLE');
        }}
        onRestart={handleReset}
        isMuted={isMuted}
        onToggleMute={toggleMute}
        onOpenJavaModal={() => setIsJavaModalOpen(true)}
        gameState={gameState}
        gameMode={gameMode}
        onSwitchMode={(mode) => {
          setGameMode(mode);
          if (gameState === 'PLAYING') {
            startRound(1, gridSize, mode);
            setLevel(1);
            setScore(0);
            setLives(maxLives);
          }
        }}
      />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 w-full max-w-5xl mx-auto">
        {gameState === 'TITLE' && (
          <TitleScreen
            onStart={handleStartGame}
            gameMode={gameMode}
            setGameMode={setGameMode}
            gridSize={gridSize}
            setGridSize={(sz) => setGridSize(sz)}
            isMuted={isMuted}
            onToggleMute={toggleMute}
            onOpenJavaModal={() => setIsJavaModalOpen(true)}
            highScore={highScore}
          />
        )}

        {gameState === 'PLAYING' && (
          <div className="w-full max-w-xl flex flex-col items-center gap-4 sm:gap-6 animate-in fade-in duration-300">
            {/* Top HUD */}
            <HUD
              score={score}
              level={level}
              highScore={highScore}
              lives={lives}
              maxLives={maxLives}
              streak={streak}
              statusText={statusText}
              statusType={statusType}
              memorizeProgress={memorizeProgress}
              isMemorizePhase={isMemorizePhase}
              gameMode={gameMode}
              targetCount={pattern.length}
              foundCount={correctlyClicked.size}
            />

            {/* Glowing Tile Board */}
            <GameBoard
              gridSize={gridSize}
              pattern={pattern}
              revealedTiles={revealedTiles}
              correctlyClicked={correctlyClicked}
              wrongClicked={wrongClicked}
              isRecallPhase={isRecallPhase}
              onTileClick={handleTileClick}
            />

            {/* Bottom Quick Controls & Reference Note */}
            <div className="flex items-center justify-between w-full px-4 text-xs text-slate-400">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleReset}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                  <span>Restart (R)</span>
                </button>
                <span>·</span>
                <button
                  onClick={toggleMute}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
                  <span>{isMuted ? 'Muted (M)' : 'Sound On'}</span>
                </button>
              </div>

              <button
                onClick={() => setIsJavaModalOpen(true)}
                className="hover:text-blue-400 transition-colors font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>View Java Swing Code</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Game Over Modal */}
      {gameState === 'GAME_OVER' && (
        <GameOverModal
          score={score}
          level={level}
          highScore={highScore}
          isNewHigh={isNewHigh}
          onRestart={handleReset}
          onOpenJavaModal={() => setIsJavaModalOpen(true)}
        />
      )}

      {/* Java Swing Source Code & Runner Modal */}
      <JavaCodeViewerModal
        isOpen={isJavaModalOpen}
        onClose={() => setIsJavaModalOpen(false)}
      />
    </div>
  );
}
