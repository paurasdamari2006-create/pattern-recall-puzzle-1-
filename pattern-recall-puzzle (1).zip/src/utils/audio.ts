/**
 * Procedural Web Audio API sound generator for Pattern Recall Puzzle.
 * Generates smooth, soothing melodic chimes, chord fanfares, and feedback buzzers.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Plays a single melodic note with gentle exponential decay.
   */
  public playTone(freq: number, duration: number = 0.18, type: OscillatorType = 'sine', volume: number = 0.15) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2200, this.ctx.currentTime);

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(volume, this.ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(this.ctx.currentTime);
      osc.stop(this.ctx.currentTime + duration);
    } catch {
      // Audio context might fail on restricted browser autoplay
    }
  }

  /**
   * Sound played when a tile lights up in the pattern.
   */
  public playTile(index: number = 0, baseFreq: number = 340) {
    // Pentatonic scale frequency offset
    const scale = [1, 1.125, 1.25, 1.333, 1.5, 1.667, 1.875, 2.0, 2.25, 2.5];
    const multiplier = scale[index % scale.length];
    const octave = Math.floor(index / scale.length);
    const freq = baseFreq * multiplier * Math.pow(1.5, octave);
    this.playTone(freq, 0.22, 'sine', 0.14);
  }

  /**
   * Sound played when user clicks a correct tile during recall.
   */
  public playCorrect(step: number = 0) {
    const freqs = [523.25, 587.33, 659.25, 698.46, 783.99, 880.00, 987.77, 1046.50];
    const freq = freqs[Math.min(step, freqs.length - 1)];
    this.playTone(freq, 0.18, 'triangle', 0.16);
  }

  /**
   * Sound played on mistake / wrong tile clicked.
   */
  public playMistake() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(80, this.ctx.currentTime + 0.3);

      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.3);
    } catch {}
  }

  /**
   * Sound played on round completion / victory.
   */
  public playRoundClear() {
    const chord = [523.25, 659.25, 783.99, 1046.50]; // C Major
    chord.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.35, 'sine', 0.15);
      }, i * 70);
    });
  }

  /**
   * Sound played when game over occurs.
   */
  public playGameOver() {
    const notes = [440, 415, 392, 349];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.4, 'sawtooth', 0.12);
      }, i * 140);
    });
  }
}

export const sound = new SoundEngine();
